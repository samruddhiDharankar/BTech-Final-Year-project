
 
 <span onclick="scrollup();" class="scroll glyphicon glyphicon-arrow-up"></span>
		     			
    <div class="hexscale" style="display: none;">
     <span>0</span>
     00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f
    </div>
   
    <div class="hexscroll">
     <div></div>     
    </div> 
    <div class="hexoffset">   
     <input type="text" onblur="$('this').val($(this).attr('alt'));" onfocus="$(this).attr('alt',$(this).val());$(this).val('');" />
     <div></div>
    </div>
    <div class="hexdump">   
    </div>    
    <div class="hextext">   
    </div>   
        
  <span onclick="scrolldown();" class="scroll glyphicon glyphicon-arrow-down"></span>
		     			